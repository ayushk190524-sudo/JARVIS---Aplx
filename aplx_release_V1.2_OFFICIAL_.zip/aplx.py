import os
import subprocess #this is important for the code to use facts of the system
import shutil
import time
import webbrowser
from datetime import datetime
import sys #this is used for the aplx to know time and date

#sha256 verification:- d811f70af482aced1adeedcc5bc0362206c6222713a3940c393446fb0fe7083a (if this code was not available in any other files from anyone else, delete it.



import os

import os

def print_aplx_red_interface():
    # ANSI Color Codes
    RED = "\033[1;31m"
    DIM = "\033[2m"
    WHITE = "\033[0m"
    RESET = "\033[0m"

    # The CLAW-style heavy block logo
    banner = f"""
{RED}
  ██████▒▒▒  ███████▒▒▒  ██▒▒▒▒▒▒▒▒  ██▒▒▒▒▒▒██
  ██░░░░██▒  ██░░░░░██▒  ██▒▒▒▒▒▒▒▒  ▒██▒▒▒▒██▒
  ████████▒  █████████▒  ██▒▒▒▒▒▒▒▒  ▒▒██▒▒██▒▒
  ██░░░░██▒  ██░░░░░░░▒  ██▒▒▒▒▒▒▒▒  ▒▒▒████▒▒▒     {RED}👑THE TRUE ONE, AWAKENED!👑
  ██░░░░██▒  ██░░░░░░░▒  █████████▒  ▒▒██▒▒██▒▒      
  ██░░░░██▒  ██░░░░░░░▒  █████████▒  ▒██▒▒▒▒██▒
  ▒▒▒▒▒▒▒▒▒  ▒▒▒▒▒▒▒▒▒▒  ▒▒▒▒▒▒▒▒▒▒  ▒▒▒▒▒▒▒▒▒▒   
{RESET}"""

    # Print the Logo and Status
    print(banner)
    print(f"{RED} [Aplx is active - running currently - Local system of user]{RESET}")
    
    # Print the Commands
    print(f"\n{WHITE}Type {RED}/help{WHITE} to see all available modules.{RESET}")
    print(f"{DIM}─────────────────────────────────────────────────────────────{RESET}")
    print(f"{RED}/help             {DIM}Show full command manual{RESET}")
    print(f"{RED}/current-version  {DIM}Display build and repo status{RESET}")
    print(f"{RED} clear            {DIM}Reset the terminal workspace{RESET}")
    print(f"{RED}/exit             {DIM}Terminate the local instance{RESET}")
    print(f"{RED} Update            {DIM}Check for updates to Aplx AI{RESET}")
    print(f"{RED} SHA256            {DIM}Show the SHA256 hash of the current code{RESET}")
    print(f"{DIM}─────────────────────────────────────────────────────────────{RESET}\n")


def blink_awakening_text():
    RED = "\033[1;31m"
    RESET = "\033[0m"
    text = f"{RED}!AWAKENING!{RESET}"

    for _ in range(3):
        print(text)
        sys.stdout.flush()
        time.sleep(0.6)
        print("\033[A\033[K", end="")
        sys.stdout.flush()
        time.sleep(0.3)
    print(text)
    sys.stdout.flush()
    time.sleep(0.6)
    print("\033[A\033[K", end="")
    sys.stdout.flush()


def blink_awakened_text():
    RED = "\033[1;31m"
    RESET = "\033[0m"
    text = f"{RED}👑The True One, AWAKENED👑{RESET}"

    for _ in range(3):
        print(text)
        sys.stdout.flush()
        time.sleep(0.7)
        print("\033[A\033[K", end="")
        sys.stdout.flush()
        time.sleep(0.4)
    print(text)
    sys.stdout.flush()
    time.sleep(0.7)
    print("\033[A\033[K", end="")
    sys.stdout.flush()

# Run the launch
print_aplx_red_interface()


def clear_terminal_smooth():
    os.system('clear' if os.name == 'posix' else 'cls')
    time.sleep(0.1)
    blink_awakening_text()
    blink_awakened_text()
    print_aplx_red_interface()

clear_terminal_smooth()

def speak(text, delay=0.04):
    """Displays text letter by letter for that ChatGPT/Jarvis feel."""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()
    

def open_default_browser(url=None):
    try:
        target = url if url else "https://www.google.com"
        if shutil.which("xdg-open"):
            subprocess.Popen(["xdg-open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        elif shutil.which("gio"):
            subprocess.Popen(["gio", "open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        else:
            webbrowser.open(target)
    except Exception as err:
        speak(f"Unable to open browser: {err}")


def open_file_explorer():
    try:
        if shutil.which("gio"):
            subprocess.Popen(["gio", "open", "."], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        elif shutil.which("xdg-open"):
            subprocess.Popen(["xdg-open", "."], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        else:
            speak("No file explorer command is available on this system.")
    except Exception as err:
        speak(f"Could not open file explorer: {err}")


def greet_me():
    RED = "\033[1;31m"
    RESET = "\033[0m"
    user = os.environ.get('USER', 'R3nz')
    hour = datetime.now().hour

    if hour < 12:
        greet = "Good morning, R3nz"
    elif 12 <= hour < 18:
        greet = "Good afternoon, R3nz"
    else:
        greet = "Good evening, R3nz"

    print(f"--- {greet}, {user}, {RED}Aplx AI{RESET} is online..---")
greet_me()

while True:
    # so this is the command box next to the Aplx AI, you can type your commands here
    RED = "\033[1;31m"
    RESET = "\033[0m"
    user = os.environ.get('USER', 'R3nz')
    try:
        print(f"{RED}Aplx:-{RESET} What can I do for you, {user}?")
        query = input(f"{RED}{user}:- {RESET}").strip().lower()
    except (EOFError, KeyboardInterrupt):
        speak("Input interrupted. Type 'exit' or 'sleep' if you want to close the program.")
        continue

    if not query:
        continue

    RED = "\033[1;31m"
    RESET = "\033[0m"
    APLX_PREFIX = f"{RED}Aplx :- {RESET}"

    try:
        if "exit" in query or "sleep" in query or "quit" in query:
            speak(APLX_PREFIX + "System powering down, Goodbye for now, R3nz.")
            break

        elif "time" in query:
            now = datetime.now().strftime("%I:%M:%S %p")
            speak(APLX_PREFIX + f"The current time is {now}.")
        
        elif "intro" in query or "introduction" in query or "about you" in query:
            speak(APLX_PREFIX + f"I am {RED}Aplx AI{RESET}, your {RED}personal assistant{RESET}. Current version of me is {RED}V1.01{RESET}. I am run offline through {RED}no API{RESET} needed and if you want to access the net... well, you will need internet if you want me to {RED}open online things{RESET}.")
        elif "battery" in query or "btry" in query or "battry" in query:
            if os.path.exists('/sys/class/power_supply/BAT0/capacity'):
                with open('/sys/class/power_supply/BAT0/capacity', 'r') as f:
                    percentage = f.read().strip()
                speak(APLX_PREFIX + f"Current Power percentage: {percentage}%")
            else:
                speak(APLX_PREFIX + "Battery information not available.")
        elif "browser" in query or "internet" in query:
            speak(APLX_PREFIX + "Opening your default web browser...")
            open_default_browser()
        elif "file" in query or "folder" in query:
            speak(APLX_PREFIX + "Opening your file explorer...")
            open_file_explorer()
        elif "SHA256" in query or "sha256" in query:
            import hashlib
            with open(__file__, "rb") as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
            print(f"The SHA256 hash of the current code is: {file_hash}")
        elif "youtube" in query:
            speak(APLX_PREFIX + "Opening YouTube...")
            open_default_browser("https://www.youtube.com")
        elif "roblox" in query or "sober" in query:
            speak(APLX_PREFIX + "Opening Roblox website...")
            open_default_browser("https://www.roblox.com")
        elif "nerd app" in query or "mission jeet" in query or "hell" in query:
            speak(APLX_PREFIX + "Opening Mission Jeet (or, nerd app as you say)...")
            open_default_browser("https://missionjeet.in/")
        elif "shop" in query or "amazon" in query:
            speak(APLX_PREFIX + "Opening Amazon...")
            open_default_browser("https://www.amazon.in/")
        elif "government" in query:
            speak(APLX_PREFIX + "Opening government website...")
            open_default_browser("https://www.MyGov.in/")
        elif "updates" in query or "update" in query:
            speak(APLX_PREFIX + "Checking for updates...")
            # Placeholder for update checking logic
            speak(APLX_PREFIX + "You are running the latest version of Aplx AI. No updates available. Current updates made :- added the big 'Aplx' banner on the launch")
        elif "idk what to say" in query or "idk what to do" in query:
            speak(APLX_PREFIX + "Just ask me to open something, R3nz. I can open your browser, file explorer, and even specific websites like YouTube, Roblox, and Amazon.")
        elif "github" in query or "code" in query or "my app" in query:
            speak(APLX_PREFIX + "Opening GitHub...")
            open_default_browser("https://github.com")
        elif "help" in query or "commands" in query or "/help" in query:
            RED = "\033[1;31m"
            RESET = "\033[0m"
            speak(APLX_PREFIX + "Here are some commands you can try:")
            speak(f"- {RED}'time'{RESET} to know the current time")
            speak(f"- {RED}'battery'{RESET} to check battery percentage")
            speak(f"- {RED}'browser'{RESET} or {RED}'internet'{RESET} to open your default web browser")
            speak(f"- {RED}'file'{RESET} or {RED}'folder'{RESET} to open your file explorer")
            speak(f"- {RED}'youtube'{RESET} to open YouTube")
            speak(f"- {RED}'roblox'{RESET} or {RED}'sober'{RESET} to open the Roblox website")
            speak(f"- {RED}'nerd app'{RESET} or {RED}'mission jeet'{RESET} to open the Mission Jeet website")
            speak(f"- {RED}'shop'{RESET} or {RED}'amazon'{RESET} to open Amazon")
            speak(f"- {RED}'government'{RESET} to open the government website")
            speak(f"- {RED}'weather'{RESET} to open the weather forecast")
            speak(f"- {RED}'money eater'{RESET} or {RED}'pocket filled fatty'{RESET} or {RED}'a dumbass'{RESET} to open their respective websites")
            speak(f"- {RED}'github'{RESET} or {RED}'code'{RESET} or {RED}'my app'{RESET} to open GitHub")
            speak(f"- {RED}'discord'{RESET} or {RED}'dc'{RESET} or {RED}'dscrd'{RESET} to open Discord")
            speak(f"- {RED}'exit'{RESET} or {RED}'quit'{RESET} to close the AI")
        elif "sup dumbass" in query or "sup idiot" in query:
            speak(APLX_PREFIX + "Wsg loser, What you want now?.") 
        elif "weather" in query:
            speak(APLX_PREFIX + "Opening weather forecast...")
            open_default_browser("YOUR WEATHER AREA")
        elif "money eater" in query or "pocket filled fatty" in query or "a dumbass" in query:
            speak(APLX_PREFIX + "Opening A (not so) great womans wiki...")
            open_default_browser("https://en.wikipedia.org/wiki/Nirmala_Sitharaman")
        elif "discord" in query or "dc" in query or "dscrd" in query:
            speak(APLX_PREFIX + "Opening Discord...")
            open_default_browser("https://discord.com/channels/@me")
        elif "settings" in query or "control panel" in query:
            try:
                settings_opened = False
                
                # Linux desktop environments
                linux_settings = [
                    "cosmic-settings",      # Pop!_OS Cosmic
                    "gnome-control-center", # GNOME
                    "kde-open",             # KDE Plasma
                    "cinnamon-settings",    # Cinnamon
                    "xfce4-settings-manager", # XFCE
                    "dconf-editor",         # Generic alternative
                ]
                
                # Try Linux settings apps
                for settings_app in linux_settings:
                    if shutil.which(settings_app):
                        subprocess.Popen([settings_app], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
                        settings_opened = True
                        break
                
                # macOS
                if not settings_opened and sys.platform == "darwin":
                    subprocess.Popen(["open", "-a", "System Preferences"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    settings_opened = True
                
                # Windows
                if not settings_opened and sys.platform == "win32":
                    try:
                        subprocess.Popen("ms-settings:", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    except:
                        subprocess.Popen("rundll32.exe shell32.dll,Control_RunDLL", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    settings_opened = True
                
                if settings_opened:
                    speak(APLX_PREFIX + "Opening Settings...")
                else:
                    speak(APLX_PREFIX + "Settings application not found on this system.")
            except Exception as err:
                speak(APLX_PREFIX + f"An error occurred opening settings: {err}")
        else:
            speak(APLX_PREFIX + "Error, command not found")
    except Exception as err:
        speak(APLX_PREFIX + f"An error occurred handling that command: {err}")
        continue






